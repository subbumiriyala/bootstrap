/*
    1) Creating Servers
    2) Serving HTML data
    3) Serving JSON data
 */