// Create two variables and display their sum

// Find the biggest value between 2 numbers

// Find the biggest value among 3 numbers
