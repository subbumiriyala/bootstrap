// Block scoping for FOR loop

//Block scoping for if Block

// Function Scoping

// IIFE example

// Read and Write Operations for variables

// Implications of Read and Write Operations

