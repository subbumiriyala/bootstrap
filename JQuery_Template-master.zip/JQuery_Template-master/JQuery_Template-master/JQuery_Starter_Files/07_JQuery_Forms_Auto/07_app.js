$('#username').keyup(function() {
    $('#user_text').text($(this).val());
});
$('#password').keyup(function() {
    $('#pass_text').text($(this).val());
});
$('#email').keyup(function() {
    $('#email_text').text($(this).val());
});